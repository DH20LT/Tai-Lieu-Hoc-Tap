﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyMath
{
    class TuGiac
    {
        public int Canh;
        public float DienTich;
        public float ChuVi;
        public void HienThongTin()
        {

        }
    }
}
